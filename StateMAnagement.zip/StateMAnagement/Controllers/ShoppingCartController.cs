//  we have to create index method to create session
//add method of get to get flower by id return view
//at http post menthod open form to get new quantity
//set session for add method
//get session data at index call

using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Model.Flower;
using Model.Cart;
using Service.Interface;
using SessionHelpers;
using StateMAnagement.Models;

namespace StateMAnagement.Controllers;

public class ShoppingCartController : Controller
{
    private readonly IFlowerService _flowerService;

    public ShoppingCartController(IFlowerService flowerService)
    {
        _flowerService = flowerService;
    }

    public IActionResult Index()
    {
          Cart cart=SessionHelper.GetObjectFromSession<Cart>(HttpContext.Session,"cart");
            if (cart == null)
            {
                cart = new Cart();
                cart.Items = new List<Item>();
            }
          ViewData["CartItems"] =cart;
          return View();

// for List of item
// var items=SessionHelper.GetObjectFromSession<List<Item>>(HttpContext.Session,"cart");
// ViewData["CartItems"] = items;
// return View();

// for item
        // var item = SessionHelper.GetObjectFromSession<Item>(HttpContext.Session, "cart");
        // ViewData["CartItems"] = item;
        // return View();
    }

    [HttpGet]
    public IActionResult Add(int id)
    {
        Flower flower=  _flowerService.getFlowerById(id);
        ViewData["FlowerById"] =flower;
        return View();
    }

    // [HttpPost]
    //     public IActionResult Add(int flowerId,string flowerName, int quantity)
    //     {
    //         Item item=new Item
    //         {
    //             FlowerId= flowerId,
    //             FlowerName=flowerName,
    //             Quantity=quantity
    //         };

    //         //SessionHelper.SetJsonObject(HttpContext.Session,"cart",item);

    // // for cart
    //         //  cart=new Cart();
    //         Cart  cart =SessionHelper.GetObjectFromSession<Cart>(HttpContext.Session,"cart");
    //         if(cart==null)
    //         {
    //             cart=new Cart();
    //             cart.Items=new List<Item>();
    //         }
    //         cart.Items.Add(item);
    //         SessionHelper.SetJsonObject(HttpContext.Session, "cart", cart);



    // // for list of item
    //         // List<Item> items = new List<Item>();
    //         //  items = SessionHelper.GetObjectFromSession<List<Item>>(HttpContext.Session, "cart");
    //         // items.Add(item);
    //         //  SessionHelper.SetJsonObject(HttpContext.Session, "cart", items);


    // // for item
    //          //SessionHelper.SetJsonObject(HttpContext.Session, "cart", item);

    //         return RedirectToAction("Index", "Shoppingcart");
    //     }

    [HttpPost]
    public IActionResult Add(int flowerId, string flowerName, int quantity)
    {
        // Retrieve cart from session or initialize a new one
        Cart cart = SessionHelper.GetObjectFromSession<Cart>(HttpContext.Session, "cart");
        if (cart == null)
        {
            cart = new Cart();
        }

        // Ensure the Items list is initialized
        if (cart.Items == null)
        {
            cart.Items = new List<Item>();
        }

        // Create and add the item
        var item = new Item
        {
            FlowerId = flowerId,
            FlowerName = flowerName,
            Quantity = quantity
        };
        cart.Items.Add(item);

        // Save the cart back to the session
        SessionHelper.SetJsonObject(HttpContext.Session, "cart", cart);

        return RedirectToAction("Index", "Shoppingcart");
    }


    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
