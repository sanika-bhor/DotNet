using Repository.FlowerRepository;
using Repository.Interface;
using Service.FlowerService;
using Service.Interface;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddDistributedMemoryCache();

builder.Services.AddSession(options=>{
    options.IdleTimeout=TimeSpan.FromSeconds(20);
    options.Cookie.HttpOnly=true;
    options.Cookie.IsEssential=true;
});

//definnig services
builder.Services.AddSingleton<IFlowerRepository, FlowerRepository>();
builder.Services.AddSingleton<IFlowerService, FlowerServices>();

builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseSession();
app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
